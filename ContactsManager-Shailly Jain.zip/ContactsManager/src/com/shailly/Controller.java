package com.shailly;

import com.shailly.datamodel.Contact;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import com.shailly.datamodel.ContactData;

import java.io.IOException;
import java.util.Optional;

public class Controller {

    @FXML
    private TableView<Contact> contactTableView;

    private ContactData data;

    public void initialize(){
        data = new ContactData();
        data.loadContacts();
        contactTableView.setItems(data.getContacts());
    }


    @FXML
    private BorderPane mainPanel;

    @FXML
    public void showAddContactDialog(){
        Dialog<ButtonType> dialog = new Dialog();
        dialog.initOwner(mainPanel.getScene().getWindow());
        dialog.setTitle("Add new Contact");
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("contactDialog.fxml"));
        try{
            dialog.getDialogPane().setContent(loader.load());
        }catch (IOException e){
            System.out.println("Couldn't load the dialog.");
            e.printStackTrace();
            return;
        }
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK,ButtonType.CANCEL);
        Optional<ButtonType> result = dialog.showAndWait();
        if(result.isPresent() && result.get()==ButtonType.OK){
            ContactController contactController = loader.getController();
            Contact contact = contactController.getNewContact();
            data.addContact(contact);
            data.saveContacts();
        }
    }

    @FXML
    public void showEditContactDialog(){
        Contact selectedContact =  contactTableView.getSelectionModel().getSelectedItem();
        if(selectedContact == null){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("No contact selected.");
            alert.setHeaderText(null);
            alert.setContentText("Please set the  contact you want to edit.");
            alert.showAndWait();
            return;
        }
        Dialog<ButtonType> dialog = new Dialog();
        dialog.initOwner(mainPanel.getScene().getWindow());
        dialog.setTitle("Edit Contact");
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("contactDialog.fxml"));
        try{
            dialog.getDialogPane().setContent(loader.load());
        }catch (IOException e){
            System.out.println("Couldn't load the dialog.");
            e.printStackTrace();
            return;
        }
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK,ButtonType.CANCEL);
        ContactController contactController = loader.getController();
        contactController.editContact(selectedContact);

        Optional<ButtonType> result = dialog.showAndWait();
        if(result.isPresent() && result.get()==ButtonType.OK) {
            contactController.updateContact(selectedContact);
            data.saveContacts();
        }
    }

    public void deleteContact(){
        Contact selectedContact =  contactTableView.getSelectionModel().getSelectedItem();
        if(selectedContact == null){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("No contact selected.");
            alert.setHeaderText(null);
            alert.setContentText("Please set the  contact you want to delete.");
            alert.showAndWait();
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Delete Contact");
        alert.setHeaderText(null);
        alert.setContentText("Are you sure want to delete " +
                selectedContact.getFirstName() + " " + selectedContact.getLastName() + " ?" );
        Optional<ButtonType> result = alert.showAndWait();
        if(result.isPresent() && result.get() == ButtonType.OK){
            data.deleteContact(selectedContact);
            data.saveContacts();
        }

    }
}
