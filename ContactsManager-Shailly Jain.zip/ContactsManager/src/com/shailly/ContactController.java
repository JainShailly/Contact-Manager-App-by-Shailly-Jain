package com.shailly;

import com.shailly.datamodel.Contact;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class ContactController {
    @FXML
    public TextField firstNameField;
    @FXML
    public TextField  lastNameField;
    @FXML
    public TextField phoneNumberField;
    @FXML
    public TextField notesField;


    public Contact getNewContact(){
        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        String phoneNumber = phoneNumberField.getText();
        String notes = notesField.getText();
        Contact contact = new Contact(firstName,lastName,phoneNumber,notes);
        return contact;
    }

    public void editContact(Contact item){
        firstNameField.setText(item.getFirstName());
        lastNameField.setText(item.getLastName());
        phoneNumberField.setText(item.getPhoneNumber());
        notesField.setText(item.getNotes());
    }

    public void updateContact(Contact item){
        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        String phoneNumber = phoneNumberField.getText();
        String notes = notesField.getText();
        item.setFirstName(firstName);
        item.setLastName(lastName);
        item.setPhoneNumber(phoneNumber);
        item.setNotes(notes);
    }
}
